//
//  ViewController.swift
//  Potfolio_201716054_B
//
//  Created by 203 on 2022/06/14.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

